from django.shortcuts import render,redirect
from .models import *
def task_add(request):
    if request.method=='POST':
        task=request.POST.get('task_name')
        if task is not None:
            TODO(name=task).save()
            print('save')
            return redirect('task_add')
    all_task=TODO.objects.all().order_by('-id')
    context={'all_task':all_task}
    return render(request,'task_add.html',context)
def delete(request,id):
    pi=TODO.objects.get(id=id)
    pi.delete()
    return redirect('task_add')
def task_update(request,id):
    if request.method=='POST':
        task=request.POST.get('name')
        all_task = TODO.objects.get(id=id)
        all_task.name=task
        all_task.save()
        return redirect('task_add')

    all_task=TODO.objects.get(id=id)
    context={'data':all_task}
    return render(request,'task_update.html',context)
