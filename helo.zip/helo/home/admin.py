
from home.models import *
from django.contrib import admin
from home.models import *

admin.site.register(TODO)
