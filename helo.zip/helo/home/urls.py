from django.urls import path
from django import views
from home.views import *

urlpatterns = [
    path('task_add',task_add,name='task_add' ),
    path('delete/<int:id>',delete,name='delete'),
    path('task_update/<int:id>',task_update,name='task_update'),

    
]
